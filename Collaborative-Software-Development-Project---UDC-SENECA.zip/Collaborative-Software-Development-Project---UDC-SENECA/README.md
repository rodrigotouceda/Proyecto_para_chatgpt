# Collaborative-Software-Development-Project---UDC-SENECA
This repository is part of a collaborative software development project between students from UDC and the SENECA program. All changes and updates must be reflected in this repository to facilitate and optimize group work.
